import os
import re
import nltk
import numpy as py
import pandas as pd
from nltk.stem import WordNetLemmatizer
from nltk.tokenize import word_tokenize
from sklearn.model_selection import train_test_split

#from Preprocessing import Preprocessing
from NaiveBayes import NaiveBayesClassifier
from SGD import SparseSGDClassifier
from FeatureExtraction import tfidfVectorizer
from FeatureExtraction import CountVectorizer

negDir = r'C:\Users\hp\Desktop\Year 3 CS & AI\Natural Language Processing\Semantic_Analysis\data\neg'
posDir = r'C:\Users\hp\Desktop\Year 3 CS & AI\Natural Language Processing\Semantic_Analysis\data\pos'

# Initialize lists to store data read from files
negative = [[0]*2 for i in range(2000)]
positive = [[1]*2 for i in range(2000)]

# Iterate directory
counter = 0
for file_path in os.listdir(negDir):
    # check if current file_path is a file
    if os.path.isfile(os.path.join(negDir, file_path)):
        with open(negDir + "\\" + file_path, encoding="utf8") as file:  
            negative[counter][0] = file.read()
            counter += 1

counter = 0
for file_path in os.listdir(posDir):
    # check if current file_path is a file
    if os.path.isfile(os.path.join(posDir, file_path)):
        with open(posDir + "\\" + file_path, encoding="utf8") as file:  
            positive[counter][0] = file.read()
            counter += 1

negDf = pd.DataFrame(negative, columns = ["review", "sentiment"])
posDf = pd.DataFrame(positive, columns = ["review", "sentiment"])

dataDf = pd.concat([negDf, posDf], axis = 0)
dataDf = dataDf.sample(frac=1, random_state=42).reset_index(drop=True)

reviews = dataDf['review'].values
labels = dataDf['sentiment'].values

tfidf = tfidfVectorizer()
ngrams = CountVectorizer()

tfidftable = tfidf.fitTransform(reviews)

"""
# unigrams, tokenization, stopword filtering, lemmatization, no stemming, and tfidf
preprocessor1 = Preprocessing(1,tokenization=True, stopwords=True, lemmatization=True, stemming=False, tfidf = True)
# unigrams, tokenization, stopword filtering, no lemmatization, stemming, and tfidf
preprocessor2 = Preprocessing(1,tokenization=True, stopwords=True, lemmatization=False, stemming=True, tfidf = True)
# Bigrams, tokenization, stopword filtering, lemmatization, no stemming, and tfidf
preprocessor3 = Preprocessing(2,tokenization=True, stopwords=True, lemmatization=True, stemming=False, tfidf = True)
# trigrams, tokenization, stopword filtering, lemmatization, no stemming, and tfidf
preprocessor4 = Preprocessing(3,tokenization=True, stopwords=True, lemmatization=True, stemming=False, tfidf = True)
"""


(x_train,x_test,y_train,y_test) = train_test_split(reviews,labels,test_size = 0.2)
(x_train,x_val,y_train,y_val) = train_test_split(x_train,y_train,test_size = 0.2)

print("train", len(x_train), len(y_train), type(x_train))
print("val", len(x_val), len(y_val), type(x_train))
print("test", len(x_test), len(y_test), type(x_train))




            

            

