import torch
from transformers import BertTokenizer, BertForSequenceClassification, AdamW
from torch.utils.data import DataLoader, TensorDataset
from sklearn.metrics import accuracy_score

class CasedBertClassifier:
    def __init__(self, numLabels = 2, lr = 2e-5, epochs = 3):
        self.tokenizer = BertTokenizer.from_pretrained('bert-base-cased')
        self.model = BertForSequenceClassification.from_pretrained('bert-base-cased' , num_labels = numLabels)
        self.lr = lr
        self.epochs = epochs
        
    def tokenize_and_encode(self, texts, labels):
        tokens = self.tokenizer(texts, padding = True, truncation = True, return_tensors = 'pt')
        labels = torch.tensor(labels)
        return tokens, labels
    
    def train(self, xTrain, yTrain, xTest, yTest):
        tokenizedxTrain, yTrain = self.tokenize_and_encode(xTrain, yTrain)
        tokenizedxTest, yTest = self.tokenize_and_encode(xTest, yTest)
        
        trainData = TensorDataset(tokenizedxTrain['input_ids'], yTrain)
        testData = TensorDataset(tokenizedxTest['input_ids'], yTest)
        
        trainLoader = DataLoader(trainData, batch_size = 4, shuffle = True)
        testLoader = DataLoader(testData, batch_size = 4, shuffle = False)

        optimizer = AdamW(self.model.parameters(), lr = self.lr)
        
        for epoch in range(self.epochs):
            self.model.train()
            for batch in trainLoader:
                inputs, labels = batch
                outputs = self.model(inputs, labels=labels)
                loss = outputs.loss
                loss.backward()
                optimizer.step()
                optimizer.zero_grad()
            
            self.model.eval()
            testPreds = []
            testTrue = []
            with torch.no_grad():
                for batch in testLoader:
                    inputs, labels = batch
                    outputs = self.model(inputs)
                    logits = outputs.logits
                    preds = torch.argmax(logits, dim=1)
                    testPreds.extend(preds.numpy())
                    testTrue.extend(labels.numpy())
            
            accuracy = accuracy_score(testTrue, testPreds)
            print(f"Cased BERT - Epoch {epoch + 1}/{self.num_epochs}, Validation Accuracy: {accuracy}")
            
            def predict(self,texts):
                tokenizedTexts, _ = self.tokenize_and_encode(texts, labels)
                self.model.eval()
                
                with torch.no_grad():
                    outputs = self.model(**tokenizedTexts)
                    logits = outputs.logits
                    predictions = torch.argmax(logits, dim = 1).numpy()
                    
                return predictions
            
class UncasedBertClassifier:
    def __init__(self, numLabels = 2, lr = 2e-5, epochs = 3):
        self.tokenizer = BertTokenizer.from_pretrained('bert-base-uncased')
        self.model = BertForSequenceClassification.from_pretrained('bert-base-uncased' , num_labels = numLabels)
        self.lr = lr
        self.epochs = epochs
        
    def tokenize_and_encode(self, texts, labels):
        tokens = self.tokenizer(texts, padding = True, truncation = True, return_tensors = 'pt')
        labels = torch.tensor(labels)
        return tokens, labels
    
    def train(self, xTrain, yTrain, xTest, yTest):
        tokenizedxTrain, yTrain = self.tokenize_and_encode(xTrain, yTrain)
        tokenizedxTest, yTest = self.tokenize_and_encode(xTest, yTest)
        
        trainData = TensorDataset(tokenizedxTrain['input_ids'], yTrain)
        testData = TensorDataset(tokenizedxTest['input_ids'], yTest)
        
        trainLoader = DataLoader(trainData, batch_size = 4, shuffle = True)
        testLoader = DataLoader(testData, batch_size = 4, shuffle = False)

        optimizer = AdamW(self.model.parameters(), lr = self.lr)
        
        for epoch in range(self.epochs):
            self.model.train()
            for batch in trainLoader:
                inputs, labels = batch
                outputs = self.model(inputs, labels=labels)
                loss = outputs.loss
                loss.backward()
                optimizer.step()
                optimizer.zero_grad()
            
            self.model.eval()
            testPreds = []
            testTrue = []
            with torch.no_grad():
                for batch in testLoader:
                    inputs, labels = batch
                    outputs = self.model(inputs)
                    logits = outputs.logits
                    preds = torch.argmax(logits, dim=1)
                    testPreds.extend(preds.numpy())
                    testTrue.extend(labels.numpy())
            
            accuracy = accuracy_score(testTrue, testPreds)
            print(f"Uncased BERT - Epoch {epoch + 1}/{self.num_epochs}, Validation Accuracy: {accuracy}")
            
    def predict(self,texts):
        tokenizedTexts, _ = self.tokenize_and_encode(texts, labels = None)
        self.model.eval()
                
        with torch.no_grad():
            outputs = self.model(**tokenizedTexts)
            logits = outputs.logits
            predictions = torch.argmax(logits, dim = 1).numpy()
                    
        return predictions
         